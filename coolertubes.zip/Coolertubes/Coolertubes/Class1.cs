﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Harmony;

namespace Coolertubes
{
    public class CoolerTubes_Entrance_energy_consumption
    {
        [HarmonyPatch(typeof (TravelTubeEntranceConfig), "CreateBuildingDef")]
        public class patch_traveltubeentrance
        {
            public static void Postfix(BuildingDef __result)
            {
                __result.EnergyConsumptionWhenActive = 240f;
            }
        }
    }
    public class CoolerTubes_Entrance_joules_per_launch
    {
        [HarmonyPatch(typeof (TravelTubeEntranceConfig), "CreateBuildingDef")]
        public class patch_traveltubeentrance
        {
            public static void Postfix(BuildingDef __result)
            {
                __result.joulesPerLaunch = 10f;
            }
        }
    }
}