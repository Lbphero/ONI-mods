﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Harmony;

namespace LessWattageTubes
{
    public class LessWattageTubes_energy_consumption
    {
        [HarmonyPatch(typeof(TravelTubeEntranceConfig), "CreateBuildingDef")]
        public class patch_traveltubeentrance
        {
            public static void Postfix(BuildingDef __result)
            {
                __result.EnergyConsumptionWhenActive = 240f;
            }
        }
    }
}